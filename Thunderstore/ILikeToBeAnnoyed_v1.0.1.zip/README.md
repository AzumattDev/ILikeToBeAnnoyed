# Description

## Makes the tamed wolves howl once more. How annoying is that! This mod was a request by `Unforgiven_0_ a.k.a Ilias#7350`

`This mod is not needed on a server. It's client only. Install on each client that you wish to have the mod load. If you are using this on a server, you may notice that the wolves will not howl sometimes. This is because the owner of the chunk is the person that will control the behaviour of spawned creatures. If they do not have the mod, this will not take effect.`

`Feel free to reach out to me on discord if you need manual download assistance.`

# Author Information

### Azumatt

`DISCORD:` Azumatt#2625

`STEAM:` https://steamcommunity.com/id/azumatt/

For Questions or Comments, find me in the Odin Plus Team Discord or in mine:

[![https://i.imgur.com/XXP6HCU.png](https://i.imgur.com/XXP6HCU.png)](https://discord.gg/Pb6bVMnFb2)
<a href="https://discord.gg/pdHgy6Bsng"><img src="https://i.imgur.com/Xlcbmm9.png" href="https://discord.gg/pdHgy6Bsng" width="175" height="175"></a>
***